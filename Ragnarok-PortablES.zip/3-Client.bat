@echo off
cd /d "%~dp0Ragnarok\Game" || exit /b
start "" "2025-06-04_Ragexe_1748494356_clientinfo.xml_patched.exe"