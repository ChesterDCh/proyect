@echo off
setlocal EnableDelayedExpansion
title Idioma del cliente / Client Language
color 0B

set "BASE=%~dp0"
set "GAME=%BASE%Ragnarok\Game"
set "SYS=%GAME%\SystemEN"
set "ES=%GAME%\SystemES"
set "ENOLD=%GAME%\SystemEN_EN"
set "MSG=%GAME%\data"
set "LUA=%MSG%\luafiles514\lua files"
set "ADV=%LUA%\AdventureGuide"

:MENU
cls
color 0B
echo ============================================================
echo              IDIOMA DEL CLIENTE / CLIENT LANGUAGE
echo ============================================================
echo.
if exist "%ENOLD%" (
    echo   Idioma actual: ESPANOL
) else (
    echo   Idioma actual: ENGLISH
)
echo.
echo   1 - Espanol
echo   2 - English
echo   3 - Salir
echo.
echo ============================================================
echo.
set /p "OPT=Selecciona una opcion: "

if "%OPT%"=="1" goto SPANISH
if "%OPT%"=="2" goto ENGLISH
if "%OPT%"=="3" exit /b 0
goto MENU

:SPANISH
cls
if exist "%ENOLD%" (
    echo El cliente ya esta configurado en ESPANOL.
    echo.
    goto SYNCMSG
)
if not exist "%SYS%" (
    echo ERROR: No se encuentra la carpeta SystemEN.
    echo.
    pause
    goto MENU
)
if not exist "%ES%" (
    echo ERROR: No se encuentra la carpeta SystemES.
    echo.
    pause
    goto MENU
)

tasklist /NH 2>nul | findstr /I "Ragexe" >nul
if not errorlevel 1 (
    echo ERROR: Cierra Ragnarok antes de cambiar el idioma.
    echo.
    pause
    goto MENU
)

echo Activando los archivos en espanol...
ren "%SYS%" "SystemEN_EN"
if errorlevel 1 (
    echo ERROR: No se pudo renombrar SystemEN.
    echo Cierra el juego o cualquier programa que use esa carpeta.
    echo.
    pause
    goto MENU
)

ren "%ES%" "SystemEN"
if errorlevel 1 (
    echo ERROR: No se pudo activar SystemES. Restaurando el ingles...
    ren "%ENOLD%" "SystemEN"
    echo.
    pause
    goto MENU
)

echo.
echo Idioma cambiado a ESPANOL.
goto SYNCMSG

:ENGLISH
cls
if not exist "%ENOLD%" (
    echo El cliente ya esta configurado en ENGLISH.
    echo.
    goto SYNCMSG
)
if not exist "%SYS%" (
    echo ERROR: No se encuentra la carpeta SystemEN.
    echo.
    pause
    goto MENU
)

tasklist /NH 2>nul | findstr /I "Ragexe" >nul
if not errorlevel 1 (
    echo ERROR: Cierra Ragnarok antes de cambiar el idioma.
    echo.
    pause
    goto MENU
)

echo Restaurando los archivos en ingles...
ren "%SYS%" "SystemES"
if errorlevel 1 (
    echo ERROR: No se pudo renombrar SystemEN.
    echo Cierra el juego o cualquier programa que use esa carpeta.
    echo.
    pause
    goto MENU
)

ren "%ENOLD%" "SystemEN"
if errorlevel 1 (
    echo ERROR: No se pudo restaurar el ingles. Restaurando el espanol...
    ren "%ES%" "SystemEN"
    echo.
    pause
    goto MENU
)

echo.
echo Idioma cambiado a ENGLISH.
goto SYNCMSG

:SYNCMSG
if exist "%ENOLD%" (
    if exist "%MSG%\msgstringtable_es.txt" (
        copy /Y "%MSG%\msgstringtable_es.txt" "%MSG%\msgstringtable.txt" >nul
        echo Interfaz: espanol.
    ) else (
        echo AVISO: Falta data\msgstringtable_es.txt
    )
    if exist "%GAME%\GuildTip_es.txt" (
        copy /Y "%GAME%\GuildTip_es.txt" "%GAME%\GuildTip.txt" >nul
        echo Guia de gremio: espanol.
    ) else (
        echo AVISO: Falta GuildTip_es.txt
    )
    if exist "%LUA%\msgstring_kr_es.lub" (
        copy /Y "%LUA%\msgstring_kr_es.lub" "%LUA%\msgstring_kr.lub" >nul
        echo Teclas de acceso rapido: espanol.
    ) else (
        echo AVISO: Falta data\luafiles514\lua files\msgstring_kr_es.lub
    )
    if exist "%LUA%\msgstring_kr_s_es.lub" (
        copy /Y "%LUA%\msgstring_kr_s_es.lub" "%LUA%\msgstring_kr_s.lub" >nul
    ) else (
        echo AVISO: Falta data\luafiles514\lua files\msgstring_kr_s_es.lub
    )
    if exist "%ADV%\Guide_Intro_es.lub" (
        copy /Y "%ADV%\Guide_Intro_es.lub" "%ADV%\Guide_Intro.lub" >nul
        echo Guia de aventura: espanol.
    ) else (
        echo AVISO: Falta data\luafiles514\lua files\AdventureGuide\Guide_Intro_es.lub
    )
) else (
    if exist "%MSG%\msgstringtable_en.txt" (
        copy /Y "%MSG%\msgstringtable_en.txt" "%MSG%\msgstringtable.txt" >nul
        echo Interfaz: English.
    ) else (
        echo AVISO: Falta data\msgstringtable_en.txt
    )
    if exist "%GAME%\GuildTip_en.txt" (
        copy /Y "%GAME%\GuildTip_en.txt" "%GAME%\GuildTip.txt" >nul
        echo Guia de gremio: English.
    ) else (
        echo AVISO: Falta GuildTip_en.txt
    )
    if exist "%LUA%\msgstring_kr_en.lub" (
        copy /Y "%LUA%\msgstring_kr_en.lub" "%LUA%\msgstring_kr.lub" >nul
        echo Teclas de acceso rapido: English.
    ) else (
        echo AVISO: Falta data\luafiles514\lua files\msgstring_kr_en.lub
    )
    if exist "%LUA%\msgstring_kr_s_en.lub" (
        copy /Y "%LUA%\msgstring_kr_s_en.lub" "%LUA%\msgstring_kr_s.lub" >nul
    ) else (
        echo AVISO: Falta data\luafiles514\lua files\msgstring_kr_s_en.lub
    )
    if exist "%ADV%\Guide_Intro_en.lub" (
        copy /Y "%ADV%\Guide_Intro_en.lub" "%ADV%\Guide_Intro.lub" >nul
        echo Guia de aventura: English.
    ) else (
        echo AVISO: Falta data\luafiles514\lua files\AdventureGuide\Guide_Intro_en.lub
    )
)
echo.
echo ============================================================
echo Listo. Inicia el cliente para aplicar el cambio.
echo ============================================================
echo.
pause
goto MENU
