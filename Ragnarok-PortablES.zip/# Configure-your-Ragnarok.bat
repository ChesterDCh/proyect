@echo off
setlocal EnableDelayedExpansion
title Ragnarok Auto Configurator
color 0B

:: ============================================================
:: Ragnarok Automatic Network Configurator (No Admin / No Firewall)
:: ============================================================

:: Base directory
set BASEDIR=%~dp0

:: Target files
set FILE1=%BASEDIR%Ragnarok\Emulator\conf\char_athena.conf
set FILE2=%BASEDIR%Ragnarok\Emulator\conf\map_athena.conf
set FILE3=%BASEDIR%Ragnarok\Emulator\conf\subnet_athena.conf
set FILE4=%BASEDIR%Ragnarok\Game\data\clientinfo.xml
set FILE5=%BASEDIR%Ragnarok\Server\www\index.php
set FILE6=%BASEDIR%Ragnarok\Server\www\FluxCP\config\application.php

:: ===================== MENU =====================
:MENU
cls
color 0B
echo ============================================================
echo              RAGNAROK NETWORK CONFIGURATOR
echo ============================================================
echo.
echo   1 - OFFLINE Mode (127.0.0.1)
echo   2 - LOCAL Network Mode (IPv4)
echo   3 - VPN Mode (Radmin / Hamachi)
echo   4 - VPS / Dedicated Mode
echo   5 - Idioma / Client Language (Espanol / English)
echo.
echo ============================================================
echo.
set /p MODE=Select an option: 

if "%MODE%"=="1" goto MODE1
if "%MODE%"=="2" goto MODE2
if "%MODE%"=="3" goto MODE3
if "%MODE%"=="4" goto MODE4
if "%MODE%"=="5" goto LANGUAGE
goto MENU

:LANGUAGE
call "%BASEDIR%# Idioma.bat"
goto MENU

:: ===================== OFFLINE =====================
:MODE1
cls
color 0A
echo ============================================================
echo OFFLINE Mode
echo ============================================================
echo.
echo Server will use 127.0.0.1
echo.
set NEWVALUE=127.0.0.1
goto CONTINUE

:: ===================== LOCAL =====================
:MODE2
cls
color 0E
echo ============================================================
echo LOCAL Network Mode (IPv4)
echo ============================================================
echo.
echo To find your correct IPv4:
echo.
echo   1. Press Win + R
echo   2. Type: cmd
echo   3. Type: ipconfig
echo.
echo Example: 192.168.0.105
echo.
echo Type B to go back.
echo.
set /p NEWVALUE=Enter your LOCAL IPv4: 
if /I "%NEWVALUE%"=="B" goto MENU
goto CONTINUE

:: ===================== VPN =====================
:MODE3
cls
color 0E
echo ============================================================
echo VPN Mode (Radmin / Hamachi)
echo ============================================================
echo.
echo Use the IP shown inside Radmin or Hamachi.
echo.
echo Type B to go back.
echo.
set /p NEWVALUE=Enter your VPN IP: 
if /I "%NEWVALUE%"=="B" goto MENU
goto CONTINUE

:: ===================== VPS =====================
:MODE4
cls
color 0E
echo ============================================================
echo VPS / Dedicated Mode
echo ============================================================
echo.
echo Use your Public VPS IP.
echo.
echo Type B to go back.
echo.
set /p NEWVALUE=Enter your VPS Public IP: 
if /I "%NEWVALUE%"=="B" goto MENU
goto CONTINUE

:: ===================== PROCESS FILES =====================
:CONTINUE
cls
color 0B
echo ============================================================
echo Applying configuration...
echo ============================================================
echo.

for %%F in ("%FILE1%" "%FILE2%" "%FILE3%" "%FILE4%" "%FILE5%" "%FILE6%") do (

    if exist "%%F" (

        findstr /C:"JOWA76" "%%F" >nul

        if !errorlevel! == 0 (
            powershell -Command "(Get-Content -Raw '%%F') -replace 'JOWA76','%NEWVALUE%' | Set-Content '%%F'"
            echo [UPDATED] %%F
        ) else (
            echo [NO MATCH FOUND] %%F
        )

    ) else (
        echo [FILE NOT FOUND] %%F
    )
)

echo.
echo ============================================================
echo Operation completed successfully!
echo ============================================================
echo.
pause
goto MENU