cd /d "%~dp0Ragnarok\Server"
start "" "Laragon.exe"