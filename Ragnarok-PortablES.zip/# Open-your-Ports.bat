@echo off
title Ragnarok Firewall Opener
color 0A
setlocal EnableDelayedExpansion

:: ================================
:: Auto Elevate to Administrator
:: ================================
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit
)

cls
echo ==========================================
echo Ragnarok Online Server Ports Setup
echo ==========================================
echo.
set /p CONFIRM=Do you want to add/verify the default ports? (Y/N): 
if /I not "%CONFIRM%"=="Y" (
    echo Exiting without changes.
    pause
    exit
)

cls
echo ==========================================
echo Verifying/Adding Ragnarok Online Server Ports
echo ==========================================

:: Default Ragnarok Online ports
set PORTS=6900 6121 5121
set SKIPPED_ALL=1

for %%P in (%PORTS%) do (
    set "RULE_IN=Ragnarok %%P IN"
    set "RULE_OUT=Ragnarok %%P OUT"

    :: Check IN rule
    netsh advfirewall firewall show rule name="!RULE_IN!" >nul 2>&1
    if !errorlevel! == 0 (
        echo !RULE_IN! already exists. Skipping.
    ) else (
        netsh advfirewall firewall add rule name="!RULE_IN!" dir=in action=allow protocol=TCP localport=%%P >nul
        echo !RULE_IN! added.
        set SKIPPED_ALL=0
    )

    :: Check OUT rule
    netsh advfirewall firewall show rule name="!RULE_OUT!" >nul 2>&1
    if !errorlevel! == 0 (
        echo !RULE_OUT! already exists. Skipping.
    ) else (
        netsh advfirewall firewall add rule name="!RULE_OUT!" dir=out action=allow protocol=TCP localport=%%P >nul
        echo !RULE_OUT! added.
        set SKIPPED_ALL=0
    )
)

echo.
if !SKIPPED_ALL! == 1 (
    echo No changes needed. All ports were already configured in Windows Firewall.
) else (
    echo Ports verified/added successfully.
)
echo.
pause