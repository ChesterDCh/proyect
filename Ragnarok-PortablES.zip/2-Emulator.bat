@echo off
cd /d "%~dp0Ragnarok\Emulator"
call "runserver.bat"
exit